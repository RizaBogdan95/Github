/************************************************************************************************

	LEDEffects Library for Arduino
	
	Rev. 0.1 / 05-Aug-14 / J.Anslik

*************************************************************************************************

	See header of LEDEffects.cpp for some documentation.

************************************************************************************************/


#ifndef LEDEffects_h
#define LEDEffects_h


#include "Arduino.h"


// Add some readability (argh!)
#define MOVE_LEFT				false
#define MOVE_RIGHT				true

#define RETURN_TO_DARKNESS		false
#define STAY_HIGH				true


/*
The mighty LEDEffects class. Please note you can use the constructor to initialize
the dynamic pin array "_arrLED".
*/
class LEDEffects
{
	public:
		LEDEffects(int nNumLEDs, short *arrLED)
			: _nNumLEDs(nNumLEDs), _arrLED(arrLED) {}
		
		void InitLEDPins() { for(int i = 0; i < _nNumLEDs; i++) pinMode(_arrLED[i], OUTPUT); }
		void OneByOne(boolean bDir, int nDelay, boolean bMode);
		void SingleLED(boolean bDir, int nDelay, boolean bSkip);
		void DoSegments(int nSegments, boolean bDir, int nDelay, boolean bSkip);
		void SetAllLEDs(boolean bMode);
		void BlinkAllLEDs(int nDelay);
		void RandomTrigger(boolean bMode, int nDelay);
		void ToCenter(int nDelay);
		void FromCenter(boolean bMode, boolean bKeep, int nDelay);
	
	private:
		int _nNumLEDs;			// Amount of LEDs, determined by sizeof(_arrLED)/sizeof(short)
		short *_arrLED;			// Array to hold the pin numbers
};

#endif