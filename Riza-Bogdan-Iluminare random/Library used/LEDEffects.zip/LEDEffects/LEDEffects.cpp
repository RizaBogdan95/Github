/************************************************************************************************

	LEDEffects Library for Arduino
	
	Rev. 0.1 / 05-Aug-14 / J.Anslik

*************************************************************************************************

Note:	Some functions use constans like "MOVE_LEFT" or "MOVE_RIGHT", assuming your LEDs are arranged
		in a straight line, like this:

			+---+---+---+---+---+---+---+---+
			| 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
			+---+---+---+---+---+---+---+---+

		There's also some simple math involved in some of the functions, to determine the "center"
		of the LED strip, etc. These work best with an even number of LEDS (8, 12, 16, whatever).

*************************************************************************************************

	I included a working example in this archive: "LEDEffects_Example.ino".........anyway:

	Sample code:

		#include <LEDEffects.h>

		// Pins to use for LEDs
		short arrLED[] = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };

		// Determine total amount of LEDs in the array
		const int nNumLEDs = sizeof(arrLED)/sizeof(short);

		// And here's your very own LEDEffects class!
		LEDEffects LED(nNumLEDs, arrLED);

		void setup() {
  
			// Init pins to OUTPUT
			LED.InitLEDPins();
		}

		void loop() {

			// Light up all LEDs in random order
			LED.RandomPopulate(HIGH, 100);

			delay(1000);

			// Switch off all LEDs in random order
			LED.RandomPopulate(LOW, 100);

			// Blink all LEDs three times
			for(i = 0; i < 3; i++) {
		
				LED.BlinkAllLEDs(250);

				delay(250);
			}

			delay(1000);
		}

************************************************************************************************/


#include "Arduino.h"
#include "LEDEffects.h"


/////////////////////////////////////////////////////////////////////////
// Switch LEDs on or off, one by one.
//
// bDirection:	From left to right (MOVE_RIGHT) or vice versa (MOVE_LEFT)
// nDelay:		Delay before triggering next LED
// bMode:		HIGH or LOW
/////////////////////////////////////////////////////////////////////////
void LEDEffects::OneByOne(boolean bDirection, int nDelay, boolean bMode) {

	if(bDirection == MOVE_RIGHT) {

		for(int nPos = 0; nPos < _nNumLEDs; nPos++) {

			digitalWrite(_arrLED[nPos], bMode);
			delay(nDelay);
		}
	}
	else {

		for(int nPos = _nNumLEDs-1; nPos >= 0; nPos--) {

			digitalWrite(_arrLED[nPos], bMode);
			delay(nDelay);
		}
	}
}


/////////////////////////////////////////////////////////////////////////
// The classic running light, using a single LED
//
// bDirection:	From left to right (MOVE_RIGHT) or vice versa (MOVE_LEFT)
// nDelay:		Delay before triggering next LED
// bSkip:		Skip first or last LED to avoid double triggering
/////////////////////////////////////////////////////////////////////////
void LEDEffects::SingleLED(boolean bDirection, int nDelay, boolean bSkip) {

	if(bDirection == MOVE_RIGHT) {

		for(int nPos = bSkip ? 1 : 0; nPos < _nNumLEDs; nPos++) {
     
			digitalWrite(_arrLED[nPos], HIGH);
			delay(nDelay);
			digitalWrite(_arrLED[nPos], LOW);
		}
	}
	else {
		
		for(int nPos = bSkip ? _nNumLEDs-2 : _nNumLEDs-1; nPos >= 0; nPos--) {
    
			digitalWrite(_arrLED[nPos], HIGH);
			delay(nDelay);
			digitalWrite(_arrLED[nPos], LOW);
		}
	}
}


/////////////////////////////////////////////////////////////////////////
// Divide LED "strip" into segments, with one running light per segment
//
// nSegments:	Number of segments
// bDirection:	From left to right (MOVE_RIGHT) or vice versa (MOVE_LEFT)
// nDelay:		Delay before triggering next LED
// bSkip:		Skip first or last LED to avoid double triggering
/////////////////////////////////////////////////////////////////////////
void LEDEffects::DoSegments(int nSegments, boolean bDirection, int nDelay, boolean bSkip) {

	int segidx = _nNumLEDs/nSegments;
	int nOffset;
	int nPos;


	if(bDirection == MOVE_RIGHT) {
			
		for(nOffset = bSkip ? 1 : 0; nOffset < segidx; nOffset++) {

			for(nPos = 0; nPos < nSegments; nPos++) {
					
				digitalWrite(_arrLED[(nPos*segidx)+nOffset], HIGH);
			}

			delay(nDelay);

			for(nPos = 0; nPos < nSegments; nPos++) {
					
				digitalWrite(_arrLED[(nPos*segidx)+nOffset], LOW);
			}
		}
	}
	else {

		for(nOffset = bSkip ? segidx-2 : segidx-1; nOffset >= 0; nOffset--) {

			for(nPos = nSegments-1; nPos >= 0; nPos--) {
					
				digitalWrite(_arrLED[(nPos*segidx)+nOffset], HIGH);
			}

			delay(nDelay);

			for(nPos = nSegments-1; nPos >= 0; nPos--) {
					
				digitalWrite(_arrLED[(nPos*segidx)+nOffset], LOW);
			}
		}
	}
}


//////////////////////////
// Turn all LEDs on or off
//
// bMode:	HIGH or LOW
//////////////////////////
void LEDEffects::SetAllLEDs(boolean bMode) {
  
	for(int nPos = 0; nPos < _nNumLEDs; nPos++)
		digitalWrite(_arrLED[nPos], bMode);
}


//////////////////////////////////////
// Blink all LEDs
//
// nDelay:	Pause between HIGH --> LOW
//////////////////////////////////////
void LEDEffects::BlinkAllLEDs(int nDelay) {
	
	SetAllLEDs(HIGH);
	delay(nDelay);
	SetAllLEDs(LOW);
}



////////////////////////////////////////////////
// Turn all LEDs on or off, in random succession
//
// bMode:		HIGH or LOW
// nDelay:		Delay before triggering next LED
////////////////////////////////////////////////
void LEDEffects::RandomTrigger(boolean bMode, int nDelay) {

	int nCount = 0;
	int nPos;


	randomSeed(analogRead(0));

	while(nCount < _nNumLEDs) {

		nPos = random(_nNumLEDs);

		// I've seen this LED before, go get another random number
		if(digitalRead(_arrLED[nPos]) == bMode)
			continue;

		digitalWrite(_arrLED[nPos], bMode);

		nCount++;

		delay(nDelay);
	}
}


/////////////////////////////////////////////////////////////////////
// Move one LED from the left and one from the right towards "center"
//
// nDelay:	Delay before triggering next LED
/////////////////////////////////////////////////////////////////////
void LEDEffects::ToCenter(int nDelay) {
	
	for(int nPos = 0; nPos < _nNumLEDs; nPos++) {
    
		// Skip center position(s) to avoid double triggering
		if(nPos == (int)(_nNumLEDs/2)-1)
			++nPos;

		digitalWrite(_arrLED[nPos], HIGH);
		digitalWrite(_arrLED[_nNumLEDs-1-nPos], HIGH);
    
		delay(nDelay);
    
		digitalWrite(_arrLED[nPos], LOW);
		digitalWrite(_arrLED[_nNumLEDs-1-nPos], LOW);
	}
}


///////////////////////////////////////////////////////////////////////////////////////////
// Move two LEDs from center to left and right
//
// bMode:		HIGH or LOW
// bKeep:		Previous LEDs stay lit (STAY_HIGH) or become LOW again (RETURN_TO_DARKNESS) 
// nDelay:		Delay before triggering next LED
///////////////////////////////////////////////////////////////////////////////////////////
void LEDEffects::FromCenter(boolean bMode, boolean bKeep, int nDelay) {

	int nCenterIdx = (int)(_nNumLEDs/2)-1;


	for(int nPos = nCenterIdx; nPos >= 0; nPos--) {

		digitalWrite(_arrLED[nPos], bMode);
		digitalWrite(_arrLED[_nNumLEDs-nPos-1], bMode);

		delay(nDelay);

		// Keep HIGH state for this LED?
		if(bKeep == STAY_HIGH)
			continue;

		digitalWrite(_arrLED[nPos], !bMode);
		digitalWrite(_arrLED[_nNumLEDs-nPos-1], !bMode);
	}

	if(bMode == HIGH)
		SetAllLEDs(LOW);
}